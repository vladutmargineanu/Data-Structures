/**
 * LabSD 5
 * hashtable.h
 * Purpose: Skeleton code for Hashtable.
 *
 * @authors Razvan Radoi, Alex Selea
 * @changes Ioana Stefan
 */

#ifndef __HASHTABLE__H
#define __HASHTABLE__H
#include <algorithm>
#include <iterator>
#include <list>

#define TRESHOLD 0.75

template <typename Tkey, typename Tvalue> struct elem_info {
	Tkey key;
	Tvalue value;
};

template <typename Tkey, typename Tvalue> class Hashtable {
private:
	std::list<struct elem_info<Tkey, Tvalue> > * H; // pointer to buckets
	int HMAX; // number of buckets
	unsigned int (*hash)(Tkey); // pointer to hash function
	unsigned int size; // number of elements in hashtable

public:
	Hashtable(int hmax, unsigned int (*h)(Tkey)) {
		// TODO 2: initializations, use *h as hash function
	}

	~Hashtable() {
		// TODO 2: free memory
	}

	void put(Tkey key, Tvalue value) {
		// TODO 2
 	}

	void remove(Tkey key) {
		// TODO 2
	}

	Tvalue get(Tkey key) {
		// TODO 2
		return Tvalue();
	}

	bool has_key(Tkey key) {
		// TODO 2
		return false;
	}

	void resize() {
		//TODO BONUS
	}

	int get_size() {
		return size;
	}

	int get_capacity() {
		return HMAX;
	}

	float current_factor(){
		return (float)(size) / (float)(HMAX);
	}
};

#endif //__HASHTABLE__
