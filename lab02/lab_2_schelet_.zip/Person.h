#ifndef __PERSON_H
#define __PERSON_H

#include <stdio.h>
#include <string.h>

class Person {
public:
	char* name;
	int age;

	/* TODO: Implement constructor method 
	Person(char* newName, int newAge) {
	}*/

	/* TODO: Add copy constructor method */

	/* TODO: Overload copy assignment operator */

	/* TODO: Add destructor method */
	
	/* TODO: Overload << operator - Friend function declaration
    friend std::ofstream &operator<<...*/
};

/* TODO: Overload << operator - Friend function implementation 
		Person p should be printed as:
			p.name's age is p.age\n */

#endif