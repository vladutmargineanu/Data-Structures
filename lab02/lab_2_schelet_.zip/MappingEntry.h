#ifndef __MAPPING_ENTRY_H
#define __MAPPING_ENTRY_H

#include <stdio.h>
#include <string.h>

using namespace std;

#define MAX_LENGTH 255

class MappingEntry {
private:
	int key;
	char *value;

public:
	/* TODO: Add constructor method
	MappingEntry(int key, char *value){...}*/

	/* TODO: Add destructor method
	~MappingEntry() {...}*/

	/* TODO: Implement getters for key and value */
};

#endif